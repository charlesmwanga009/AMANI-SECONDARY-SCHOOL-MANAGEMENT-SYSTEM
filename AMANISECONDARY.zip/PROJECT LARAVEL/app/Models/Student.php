<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    protected $fillable = [
        'first_name',
        'last_name',
        'admission_number',
        'date_of_birth',
        'gender',
        'class_id',
        'parent_contact',
        'address',
        'enrollment_date',
        'status' // active, suspended, alumni
    ];

    /**
     * Get the class that the student belongs to.
     */
    public function schoolClass()
    {
        return $this->belongsTo(SchoolClass::class, 'class_id');
    }

    /**
     * Get the fee payments for the student.
     */
    public function payments()
    {
        return $this->hasMany(FeePayment::class);
    }
}
