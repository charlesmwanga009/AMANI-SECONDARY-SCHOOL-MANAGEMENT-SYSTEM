<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FeePayment;
use App\Models\FeeStructure;

class FinanceController extends Controller
{
    /**
     * Display the financial dashboard.
     */
    public function index()
    {
        // Mock data for the view
        $recent_transactions = [
            (object)['id' => 'TRX-9821', 'student' => 'Sarah Lee', 'amount' => 500, 'date' => '2025-12-14', 'status' => 'completed'],
            (object)['id' => 'TRX-9822', 'student' => 'Michael Chen', 'amount' => 1200, 'date' => '2025-12-14', 'status' => 'pending'],
            (object)['id' => 'TRX-9823', 'student' => 'Jessica Davis', 'amount' => 500, 'date' => '2025-12-13', 'status' => 'completed'],
        ];

        $summary = [
            'daily_collection' => 15000,
            'outstanding' => 450000,
            'expenses' => 3200
        ];

        return view('finance.index', compact('recent_transactions', 'summary'));
    }

    /**
     * Show the form for creating a new payment.
     */
    public function create()
    {
        return view('finance.create');
    }
}
