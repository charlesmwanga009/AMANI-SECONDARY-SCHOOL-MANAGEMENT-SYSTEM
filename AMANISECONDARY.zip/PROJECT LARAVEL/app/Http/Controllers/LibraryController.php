<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class LibraryController extends Controller
{
    public function index()
    {
        // Mock data
        $books = [
            (object)['title' => 'Advanced Physics', 'author' => 'Dr. K. S. Chand', 'available' => 12, 'total' => 15, 'category' => 'Science'],
            (object)['title' => 'Modern World History', 'author' => 'H. J. Wells', 'available' => 4, 'total' => 10, 'category' => 'History'],
            (object)['title' => 'Organic Chemistry', 'author' => 'Morrison & Boyd', 'available' => 22, 'total' => 25, 'category' => 'Science'],
            (object)['title' => 'Calculus I', 'author' => 'James Stewart', 'available' => 0, 'total' => 8, 'category' => 'Mathematics'],
        ];

        return view('library.index', compact('books'));
    }
}
