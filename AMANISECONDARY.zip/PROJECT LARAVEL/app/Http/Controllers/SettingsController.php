<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index()
    {
        return view('settings');
    }

    public function logout()
    {
        // In a real app, this would be Auth::logout();
        return redirect('/')->with('success', 'Logged out successfully');
    }
}
