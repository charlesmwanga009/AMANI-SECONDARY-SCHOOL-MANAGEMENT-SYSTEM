<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use App\Models\SchoolClass;

class StudentController extends Controller
{
    /**
     * Display a listing of students.
     */
    /**
     * Display a listing of students.
     */
    public function index(Request $request)
    {
        // Fetch students with their class relationship, paginated
        $students = Student::with('schoolClass')->latest()->paginate(10);

        return view('students.index', compact('students'));
    }

    /**
     * Show the form for creating a new student.
     */
    public function create()
    {
        // Fetch actual classes
        $classes = SchoolClass::all();
        
        return view('students.create', compact('classes'));
    }

    /**
     * Store a newly created student in storage.
     */
    public function store(Request $request)
    {
        // Validation Logic
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'admission_number' => 'required|string|unique:students',
            'date_of_birth' => 'required|date',
            'gender' => 'required|in:male,female',
            'class_id' => 'required|exists:school_classes,id',
            'parent_contact' => 'required|string',
            'address' => 'nullable|string',
        ]);

        // Add enrollment date
        $validated['enrollment_date'] = now();
        $validated['status'] = 'active';

        Student::create($validated);

        return redirect()->route('students.index')->with('success', 'Student enrolled successfully!');
    }

    /**
     * Display the specified student.
     */
    public function show($id)
    {
        // return view('students.show', compact('student'));
    }
}
