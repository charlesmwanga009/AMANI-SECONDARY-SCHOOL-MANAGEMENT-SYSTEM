<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SchoolClass;
use App\Models\Exam;

class AcademicController extends Controller
{
    public function index()
    {
        // Mock Data for UI
        $classes = [
            (object)['name' => 'Form 1', 'section' => 'A', 'students_count' => 45, 'teacher' => 'Mr. Juma'],
            (object)['name' => 'Form 1', 'section' => 'B', 'students_count' => 42, 'teacher' => 'Ms. Halima'],
            (object)['name' => 'Form 2', 'section' => 'A', 'students_count' => 38, 'teacher' => 'Mr. Peter'],
            (object)['name' => 'Form 4', 'section' => 'Sci', 'students_count' => 35, 'teacher' => 'Dr. Kizza'],
        ];

        $upcoming_exams = [
            (object)['name' => 'Term 1 Midterm', 'date' => '2025-03-15', 'days_left' => 14],
            (object)['name' => 'Mock Exams (F4)', 'date' => '2025-04-01', 'days_left' => 30],
        ];

        return view('academics.index', compact('classes', 'upcoming_exams'));
    }
}
