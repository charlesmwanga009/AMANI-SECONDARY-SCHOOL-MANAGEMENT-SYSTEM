<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StaffController extends Controller
{
    public function index()
    {
        $staff_stats = [
            'total' => 128,
            'present_today' => 120,
            'on_leave' => 8
        ];

        $departments = [
            'Science' => 15,
            'Math' => 12,
            'Languages' => 20,
            'humanities' => 10,
            'Sports' => 5,
            'Admin' => 8
        ];

        return view('staff.index', compact('staff_stats', 'departments'));
    }
}
