<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\FeePayment;

class DashboardController extends Controller
{
    /**
     * Display the main dashboard with key metrics.
     */
    public function index()
    {
        // In a real scenario, we would fetch live data.
        // For now, we pass mock data or rely on the view's static placeholders
        // until the database is fully seeded.
        
        $stats = [
            'total_students' => 2450, // Student::count(),
            'revenue' => 1200000, // FeePayment::sum('amount'),
            'total_teachers' => 128, // Teacher::count(),
            'attendance_rate' => 92
        ];

        return view('dashboard', compact('stats'));
    }
}
