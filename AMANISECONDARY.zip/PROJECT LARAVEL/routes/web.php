<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dashboard');
});

// Authenticated Routes (Protected by Sanctum/Fortify)
Route::middleware(['auth:sanctum', 'verified'])->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Student Management
    Route::resource('students', \App\Http\Controllers\StudentController::class);
    
    // Academic Management
    Route::get('/academics', [\App\Http\Controllers\AcademicController::class, 'index'])->name('academics.index');

    // Finance Management
    Route::get('/finance', [\App\Http\Controllers\FinanceController::class, 'index'])->name('finance.index');
    Route::get('/finance/create', [\App\Http\Controllers\FinanceController::class, 'create'])->name('finance.create');
    
    // Library Management
    Route::get('/library', [\App\Http\Controllers\LibraryController::class, 'index'])->name('library.index');

    // Staff Management
    Route::get('/staff', [\App\Http\Controllers\StaffController::class, 'index'])->name('staff.index');
    
    // Settings & Logout
    Route::get('/settings', [\App\Http\Controllers\SettingsController::class, 'index'])->name('settings');
    Route::get('/logout', [\App\Http\Controllers\SettingsController::class, 'logout'])->name('logout');
    
});
