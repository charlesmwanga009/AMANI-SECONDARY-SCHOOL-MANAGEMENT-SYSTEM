<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // School Classes (e.g., "Form 1", "Form 2")
        Schema::create('school_classes', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique(); // Form 1
            $table->string('section')->nullable(); // A, B, C (Optional)
            $table->foreignId('class_teacher_id')->nullable()->constrained('users'); // Teacher in charge
            $table->timestamps();
        });

        // Subjects (e.g., "Mathematics", "Physics")
        Schema::create('subjects', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('code')->unique(); // MATH101
            $table->foreignId('department_id')->nullable(); // Link to department if exists
            $table->timestamps();
        });

        // Subject Allocation (Which class does which subject?)
        Schema::create('class_subjects', function (Blueprint $table) {
            $table->id();
            $table->foreignId('school_class_id')->constrained('school_classes')->onDelete('cascade');
            $table->foreignId('subject_id')->constrained('subjects')->onDelete('cascade');
            $table->foreignId('teacher_id')->nullable()->constrained('users'); // Teacher for this specific subject/class
            $table->timestamps();
        });

        // Exams
        Schema::create('exams', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Term 1 Midterm
            $table->date('start_date');
            $table->date('end_date');
            $table->string('academic_year');
            $table->timestamps();
        });

        // Exam Results
        Schema::create('exam_results', function (Blueprint $table) {
            $table->id();
            $table->foreignId('exam_id')->constrained('exams')->onDelete('cascade');
            $table->foreignId('student_id')->constrained('students')->onDelete('cascade');
            $table->foreignId('subject_id')->constrained('subjects');
            $table->decimal('marks_obtained', 5, 2);
            $table->decimal('total_marks', 5, 2)->default(100);
            $table->string('grade')->nullable(); // A, B, C...
            $table->text('remarks')->nullable();
            $table->timestamps();
            
            // Scalability: Index for generating report cards quickly
            $table->index(['student_id', 'exam_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('exam_results');
        Schema::dropIfExists('exams');
        Schema::dropIfExists('class_subjects');
        Schema::dropIfExists('subjects');
        Schema::dropIfExists('school_classes');
    }
};
