<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Fee Structures: Define fees for different classes/items
        Schema::create('fee_structures', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // e.g., "Term 1 Tuition", "Exam Fee"
            $table->foreignId('class_id')->nullable()->constrained('school_classes'); // Null for global fees
            $table->decimal('amount', 10, 2);
            $table->date('due_date');
            $table->string('academic_year'); // e.g., "2025"
            $table->timestamps();
        });

        // Fee Payments: Record actual transactions
        Schema::create('fee_payments', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_id')->unique(); // Unique receipt/trans ID
            $table->foreignId('student_id')->constrained('students')->onDelete('cascade');
            $table->foreignId('fee_structure_id')->nullable()->constrained('fee_structures');
            $table->decimal('amount_paid', 10, 2);
            $table->date('payment_date');
            $table->enum('payment_method', ['cash', 'bank_transfer', 'mobile_money', 'cheque']);
            $table->string('received_by'); // Staff/Admin who collected it
            $table->enum('status', ['pending', 'completed', 'failed', 'refunded'])->default('completed');
            $table->text('remarks')->nullable();
            $table->timestamps();

            // Indexes for financial reporting performance
            $table->index(['payment_date', 'status']);
            $table->index('student_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('fee_payments');
        Schema::dropIfExists('fee_structures');
    }
};
