<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('staff_profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade'); // Link to Laravel Auth User
            $table->string('employee_id')->unique();
            $table->string('department');
            $table->string('designation'); // Teacher, Principal, Janitor
            $table->date('join_date');
            $table->decimal('basic_salary', 10, 2);
            $table->string('qualification');
            $table->text('contract_type'); // Permanent, Contract, Intern
            $table->timestamps();
        });

        Schema::create('payrolls', function (Blueprint $table) {
            $table->id();
            $table->foreignId('staff_id')->constrained('staff_profiles');
            $table->string('month_year'); // e.g., "January 2025"
            $table->decimal('basic_salary', 10, 2);
            $table->decimal('allowances', 10, 2)->default(0);
            $table->decimal('deductions', 10, 2)->default(0);
            $table->decimal('net_salary', 10, 2); // Calculated
            $table->enum('status', ['generated', 'paid', 'held'])->default('generated');
            $table->date('payment_date')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payrolls');
        Schema::dropIfExists('staff_profiles');
    }
};
