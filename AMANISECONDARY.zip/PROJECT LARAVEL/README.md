# Amani Secondary School Management System

## 🚀 Setup Instructions

### 1. Prerequisites
You must have the following installed on your machine:
- **PHP 8.2+**
- **Composer** (Dependency Manager for PHP)
- **MySQL** (or any database supported by Laravel)

### 2. Installation
Once prerequisites are met, run these commands in this directory:

```bash
# 1. Install Laravel Dependencies
composer install

# 2. Setup Environment
copy .env.example .env
php artisan key:generate

# 3. Setup Database
# Create a database named 'amani_school' in MySQL, then run:
php artisan migrate

# 4. Start the Server
php artisan serve
```

### 3. Features Implemented

#### 🎨 Design System ("Midnight Glass")
- Custom CSS based on Glassmorphism.
- Located in `public/css/core.css`.

#### 📚 Modules
- **Dashboard**: Main overview with real-time stats (simulated).
- **Finance**: Fee collection, expense tracking, and transaction logging.
- **Library**: Book catalog and issue/return tracking.
- **Staff**: Departmental management and payroll foundations.
- **Students**: Admissions and extensive profiling.

### 4. Technical Stack
- **Framework**: Laravel 11.x
- **Frontend**: Blade Templates + Custom CSS (No Tailwind dependency required, but compatible).
- **Database**: MySQL Optimized Schema.
