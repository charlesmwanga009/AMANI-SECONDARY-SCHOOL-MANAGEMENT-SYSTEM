@extends('layout')

@section('title', 'Library - Amani School System')

@section('content')

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 class="animate-fade-in">Library Resource Center</h2>
        <div style="display: flex; gap: 1rem;">
            <button class="btn btn-glass"><i data-lucide="scan-barcode"></i> Scan ISBN</button>
            <button class="btn btn-primary"><i data-lucide="plus"></i> Add Book</button>
        </div>
    </div>

    <!-- Book Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1.5rem;">
        @foreach($books as $book)
        <div class="glass-panel animate-fade-in" style="padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem;">
            <div style="height: 160px; background: rgba(0,0,0,0.2); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                <i data-lucide="book" size="48" style="color: var(--text-muted); opacity: 0.5;"></i>
            </div>
            
            <div>
                <div style="font-size: 0.75rem; color: var(--accent); text-transform: uppercase; font-weight: 600; letter-spacing: 0.05em;">{{ $book->category }}</div>
                <h3 style="font-size: 1.1rem; margin: 0.25rem 0;">{{ $book->title }}</h3>
                <div class="text-muted" style="font-size: 0.9rem;">{{ $book->author }}</div>
            </div>

            <div style="margin-top: auto; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 1rem;">
                <div style="font-size: 0.875rem;">
                    <span style="color: {{ $book->available > 0 ? '#10b981' : '#ef4444' }}; font-weight: 600;">
                        {{ $book->available }}
                    </span> 
                    <span class="text-muted">/ {{ $book->total }} avail</span>
                </div>
                <button class="btn btn-glass" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">
                    Issue
                </button>
            </div>
        </div>
        @endforeach
    </div>

@endsection
