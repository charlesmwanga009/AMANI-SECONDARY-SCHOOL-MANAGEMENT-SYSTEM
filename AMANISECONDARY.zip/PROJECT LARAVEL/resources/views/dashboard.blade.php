@extends('layout')

@section('title', 'Dashboard - Amani School System')

@section('content')
    <!-- Stats Grid -->
    <div class="stats-grid animate-fade-in" style="animation-delay: 0.1s;">
        <!-- Total Students -->
        <div class="glass-panel stat-card">
            <div style="display: flex; justify-content: space-between;">
                <span class="stat-label">Total Students</span>
                <i data-lucide="users" style="color: var(--primary);"></i>
            </div>
            <div class="stat-value">2,450</div>
            <div class="stat-change text-success">
                <i data-lucide="trending-up" size="16"></i> 12% vs last term
            </div>
        </div>

        <!-- Revenue -->
        <div class="glass-panel stat-card">
            <div style="display: flex; justify-content: space-between;">
                <span class="stat-label">Fee Collection</span>
                <i data-lucide="dollar-sign" style="color: var(--secondary);"></i>
            </div>
            <div class="stat-value">Tsh 1.2M</div>
            <div class="stat-change text-success">
                <i data-lucide="check-circle" size="16"></i> 95% cleared
            </div>
        </div>

        <!-- Teachers -->
        <div class="glass-panel stat-card">
            <div style="display: flex; justify-content: space-between;">
                <span class="stat-label">Teaching Staff</span>
                <i data-lucide="briefcase" style="color: var(--accent);"></i>
            </div>
            <div class="stat-value">128</div>
            <div class="stat-change text-muted">
                <i data-lucide="minus" size="16"></i> Stable
            </div>
        </div>
        
        <!-- Attendance -->
        <div class="glass-panel stat-card">
            <div style="display: flex; justify-content: space-between;">
                <span class="stat-label">Daily Attendance</span>
                <i data-lucide="calendar" style="color: #10b981;"></i>
            </div>
            <div class="stat-value">92%</div>
            <div class="stat-change text-danger">
                <i data-lucide="alert-circle" size="16"></i> 8 absentees
            </div>
        </div>
    </div>

    <div class="dashboard-grid animate-fade-in" style="animation-delay: 0.2s;">
        <!-- Chart Section -->
        <div class="glass-panel" style="padding: 1.5rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h3>Attendance Trends</h3>
                <select style="background: rgba(255,255,255,0.1); border: none; color: white; padding: 0.5rem; border-radius: 8px;">
                    <option>Last 30 Days</option>
                </select>
            </div>
            
            <!-- CSS Chart (Mockup) -->
            <div class="chart-container">
                <div class="bar" style="height: 60%;"></div>
                <div class="bar" style="height: 80%;"></div>
                <div class="bar" style="height: 45%;"></div>
                <div class="bar" style="height: 90%;"></div>
                <div class="bar" style="height: 75%;"></div>
                <div class="bar" style="height: 85%;"></div>
                <div class="bar" style="height: 65%;"></div>
                <div class="bar" style="height: 95%;"></div>
            </div>
            <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; color: var(--text-muted); font-size: 0.8rem;">
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span><span>Mon</span>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="glass-panel" style="padding: 1.5rem;">
            <h3>Recent Activity</h3>
            <ul class="activity-list">
                <li class="activity-item">
                    <div class="avatar" style="background: rgba(99, 102, 241, 0.2); color: var(--primary);">JD</div>
                    <div>
                        <div style="font-weight: 500;">John Doe (Admin)</div>
                        <div class="text-muted" style="font-size: 0.875rem;">Updated Exam Schedule</div>
                        <div class="text-muted" style="font-size: 0.75rem;">10:30 AM</div>
                    </div>
                </li>
                <li class="activity-item">
                    <div class="avatar" style="background: rgba(236, 72, 153, 0.2); color: var(--secondary);">SL</div>
                    <div>
                        <div style="font-weight: 500;">Sarah Lee (Student)</div>
                        <div class="text-muted" style="font-size: 0.875rem;">Returned "Physics Adv"</div>
                        <div class="text-muted" style="font-size: 0.75rem;">09:15 AM</div>
                    </div>
                </li>
                                <li class="activity-item">
                    <div class="avatar" style="background: rgba(6, 182, 212, 0.2); color: var(--accent);">FN</div>
                    <div>
                        <div style="font-weight: 500;">Finance Dept</div>
                        <div class="text-muted" style="font-size: 0.875rem;">Processed Tuition Fees</div>
                        <div class="text-muted" style="font-size: 0.75rem;">Yesterday</div>
                    </div>
                </li>
            </ul>
            <button class="btn btn-glass" style="width: 100%; margin-top: 1rem;">View All Activity</button>
        </div>
    </div>
@endsection
