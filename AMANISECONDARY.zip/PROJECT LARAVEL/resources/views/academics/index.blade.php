@extends('layout')

@section('title', 'Academic Management - Amani School System')

@section('content')

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 class="animate-fade-in">Academic Management</h2>
        <div style="display: flex; gap: 1rem;">
            <button class="btn btn-glass"><i data-lucide="calendar"></i> View Timetable</button>
            <button class="btn btn-primary"><i data-lucide="plus"></i> Create Exam</button>
        </div>
    </div>

    <div class="dashboard-grid">
        <!-- Classes Section -->
        <div style="grid-column: span 2;">
            <div class="glass-panel animate-fade-in" style="padding: 2rem;">
                <h3 style="margin-bottom: 1.5rem;">Active Classes</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem;">
                    @foreach($classes as $class)
                    <div style="background: rgba(255,255,255,0.05); padding: 1.5rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                            <div style="font-size: 1.25rem; font-weight: 700;">{{ $class->name }} <span style="color: var(--secondary); font-size: 1rem;">{{ $class->section }}</span></div>
                            <div style="background: rgba(22, 163, 74, 0.2); color: #4ade80; padding: 0.25rem 0.5rem; border-radius: 8px; font-size: 0.75rem;">Active</div>
                        </div>
                        
                        <div style="margin-bottom: 0.5rem; font-size: 0.9rem;">
                            <i data-lucide="user" size="14" class="text-muted"></i> {{ $class->teacher }}
                        </div>
                        <div style="font-size: 0.9rem;">
                            <i data-lucide="users" size="14" class="text-muted"></i> {{ $class->students_count }} Students
                        </div>

                        <button class="btn btn-glass" style="width: 100%; margin-top: 1rem; font-size: 0.8rem; padding: 0.5rem;">Manage Class</button>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Exam Schedule Side Panel -->
        <div>
            <div class="glass-panel animate-fade-in" style="padding: 1.5rem; height: 100%;">
                <h3 style="margin-bottom: 1.5rem;">Upcoming Exams</h3>
                
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    @foreach($upcoming_exams as $exam)
                    <div style="display: flex; gap: 1rem; align-items: center; padding-bottom: 1rem; border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <div style="background: rgba(234, 179, 8, 0.1); color: var(--secondary); padding: 0.8rem; border-radius: 12px; text-align: center; min-width: 60px;">
                            <div style="font-weight: 700; font-size: 1.1rem;">{{ \Carbon\Carbon::parse($exam->date)->format('d') }}</div>
                            <div style="font-size: 0.7rem; text-transform: uppercase;">{{ \Carbon\Carbon::parse($exam->date)->format('M') }}</div>
                        </div>
                        <div>
                            <div style="font-weight: 600;">{{ $exam->name }}</div>
                            <div style="color: var(--text-muted); font-size: 0.8rem;">Starts in {{ $exam->days_left }} days</div>
                        </div>
                    </div>
                    @endforeach
                </div>

                <div style="margin-top: 2rem; padding: 1rem; background: rgba(22, 163, 74, 0.1); border-radius: 12px; border: 1px solid rgba(22, 163, 74, 0.2);">
                    <div style="display: flex; gap: 0.5rem; color: #4ade80; margin-bottom: 0.5rem;">
                        <i data-lucide="file-check"></i> <strong>Report Cards</strong>
                    </div>
                    <p style="font-size: 0.85rem; color: var(--text-muted);">Term 1 reports are pending for Form 3.</p>
                    <button class="btn btn-primary" style="width: 100%; margin-top: 0.5rem; font-size: 0.8rem;">Generate Reports</button>
                </div>
            </div>
        </div>
    </div>

@endsection
