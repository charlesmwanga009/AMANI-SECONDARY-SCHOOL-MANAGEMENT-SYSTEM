<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Amani School System')</title>
    <link rel="stylesheet" href="/css/core.css">
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar glass-panel" style="border-radius: 0; border: none; border-right: 1px solid rgba(255,255,255,0.1);">
            <div class="brand">
                <i data-lucide="graduation-cap" class="text-primary"></i>
                Amani Sys
            </div>
            
            <nav>
                <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <i data-lucide="layout-dashboard"></i> Dashboard
                </a>
                <a href="{{ route('students.index') }}" class="nav-item {{ request()->routeIs('students.*') ? 'active' : '' }}">
                    <i data-lucide="users"></i> Students
                </a>
                <a href="{{ route('academics.index') }}" class="nav-item {{ request()->routeIs('academics.*') ? 'active' : '' }}">
                    <i data-lucide="book-open"></i> Academics
                </a>
                <a href="{{ route('finance.index') }}" class="nav-item {{ request()->routeIs('finance.*') ? 'active' : '' }}">
                    <i data-lucide="wallet"></i> Finance
                </a>
                <a href="{{ route('staff.index') }}" class="nav-item {{ request()->routeIs('staff.*') ? 'active' : '' }}">
                    <i data-lucide="briefcase"></i> Staff
                </a>
                <a href="{{ route('library.index') }}" class="nav-item {{ request()->routeIs('library.*') ? 'active' : '' }}">
                    <i data-lucide="library"></i> Library
                </a>
                
                <div style="margin-top: 2rem; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1rem;">
                    <a href="{{ route('settings') }}" class="nav-item {{ request()->routeIs('settings') ? 'active' : '' }}">
                        <i data-lucide="settings"></i> Settings
                    </a>
                    <a href="{{ route('logout') }}" class="nav-item" style="color: #ef4444;">
                        <i data-lucide="log-out"></i> Logout
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="header">
                <div>
                    <h2 class="animate-fade-in">Good Morning, Administrator</h2>
                    <p class="text-muted">Here's what's happening at Amani Secondary today.</p>
                </div>
                
                <div style="display: flex; gap: 1rem; align-items: center;">
                    <div class="search-bar">
                        <input type="text" placeholder="Search students, staff, or records...">
                    </div>
                    <button class="btn btn-glass" style="padding: 0.75rem; border-radius: 50%;">
                        <i data-lucide="bell"></i>
                    </button>
                    <div class="avatar">AD</div>
                </div>
            </header>

            @yield('content')

        </main>
    </div>

    <!-- Initialize Lucide Icons -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
