@extends('layout')

@section('title', 'Finance & Fees - Amani School System')

@section('content')

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 class="animate-fade-in">Financial Overview</h2>
        <a href="{{ route('finance.create') }}" class="btn btn-primary animate-fade-in">
            <i data-lucide="plus-circle"></i> Record Payment
        </a>
    </div>

    <!-- Finance Stats -->
    <div class="stats-grid animate-fade-in" style="animation-delay: 0.1s;">
        <div class="glass-panel stat-card">
            <span class="stat-label">Daily Collection</span>
            <div class="stat-value">Tsh {{ number_format($summary['daily_collection']) }}</div>
            <div class="stat-change text-success"><i data-lucide="arrow-up-right"></i> Today</div>
        </div>
        <div class="glass-panel stat-card">
            <span class="stat-label">Outstanding Fees</span>
            <div class="stat-value" style="color: #fbbf24;">Tsh {{ number_format($summary['outstanding']) }}</div>
            <div class="stat-change text-muted">Pending Collection</div>
        </div>
        <div class="glass-panel stat-card">
            <span class="stat-label">Monthly Expenses</span>
            <div class="stat-value text-danger" style="color: #ef4444;">Tsh {{ number_format($summary['expenses']) }}</div>
            <div class="stat-change text-muted">Operational Costs</div>
        </div>
    </div>

    <!-- Recent Transactions Table -->
    <div class="glass-panel animate-fade-in" style="animation-delay: 0.2s; padding: 2rem; margin-top: 2rem;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem;">
            <h3>Recent Transactions</h3>
            <button class="btn btn-glass" style="padding: 0.5rem 1rem; font-size: 0.875rem;">Export PDF</button>
        </div>

        <table style="width: 100%; text-align: left; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.1); color: var(--text-muted);">
                    <th style="padding: 1rem;">ID</th>
                    <th style="padding: 1rem;">Student Name</th>
                    <th style="padding: 1rem;">Date</th>
                    <th style="padding: 1rem;">Amount</th>
                    <th style="padding: 1rem;">Status</th>
                    <th style="padding: 1rem;">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($recent_transactions as $trx)
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;">
                    <td style="padding: 1rem; font-family: monospace;">{{ $trx->id }}</td>
                    <td style="padding: 1rem; font-weight: 500;">{{ $trx->student }}</td>
                    <td style="padding: 1rem; color: var(--text-muted);">{{ $trx->date }}</td>
                    <td style="padding: 1rem;">Tsh {{ number_format($trx->amount, 2) }}</td>
                    <td style="padding: 1rem;">
                        <span style="
                            padding: 0.25rem 0.75rem; 
                            border-radius: 50px; 
                            font-size: 0.75rem; 
                            background: {{ $trx->status == 'completed' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(251, 191, 36, 0.2)' }}; 
                            color: {{ $trx->status == 'completed' ? '#10b981' : '#fbbf24' }};
                        ">
                            {{ ucfirst($trx->status) }}
                        </span>
                    </td>
                    <td style="padding: 1rem;">
                        <button class="btn btn-glass" style="padding: 0.4rem;"><i data-lucide="more-horizontal" size="16"></i></button>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

@endsection
