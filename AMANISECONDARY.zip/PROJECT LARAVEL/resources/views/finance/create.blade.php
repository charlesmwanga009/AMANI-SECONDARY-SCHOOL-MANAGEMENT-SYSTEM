@extends('layout')

@section('title', 'Record Payment - Amani School System')

@section('content')
    
    <div style="max-width: 800px; margin: 0 auto;">
        <div style="margin-bottom: 2rem;">
            <a href="{{ route('finance.index') }}" style="color: var(--text-muted); display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                <i data-lucide="arrow-left" size="16"></i> Back to Finance
            </a>
            <h2 class="animate-fade-in">Record New Payment</h2>
            <p class="text-muted">Enter the payment details below.</p>
        </div>

        <div class="glass-panel animate-fade-in" style="padding: 2.5rem;">
            <form action="#" method="POST"> 
                {{-- In a real app, action would be route('finance.store') --}}
                @csrf
                
                <!-- Payment Info -->
                <h4 style="color: var(--secondary); margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem;">Payment Details</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                    
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Student Name / ID</label>
                        <input type="text" name="student_id" placeholder="Search student..." style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Payment Type</label>
                        <select name="type" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                            <option value="tuition">Tuition Fee</option>
                            <option value="transport">Transport</option>
                            <option value="uniform">Uniform</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Amount (Tsh)</label>
                        <input type="number" name="amount" placeholder="0.00" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Payment Date</label>
                        <input type="date" name="date" value="{{ date('Y-m-d') }}" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Reference Number</label>
                        <input type="text" name="reference" placeholder="e.g. TRX-..." style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>
                     <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Payment Method</label>
                        <select name="method" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                            <option value="cash">Cash</option>
                            <option value="bank">Bank Transfer</option>
                            <option value="mobile">Mobile Money</option>
                        </select>
                    </div>

                </div>

                <div style="display: flex; justify-content: flex-end; gap: 1rem;">
                    <button type="button" class="btn btn-glass" onclick="window.location.href='{{ route('finance.index') }}'">Cancel</button>
                    <button type="submit" class="btn btn-primary">Process Payment</button>
                </div>

            </form>
        </div>
    </div>

@endsection
