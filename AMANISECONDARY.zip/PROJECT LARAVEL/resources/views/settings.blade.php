@extends('layout')

@section('title', 'System Settings - Amani School System')

@section('content')

    <div style="max-width: 800px;">
        <h2 class="animate-fade-in" style="margin-bottom: 2rem;">System Settings</h2>

        <div class="glass-panel animate-fade-in" style="padding: 2rem; margin-bottom: 2rem;">
            <h4 style="color: var(--secondary); margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem;">
                <i data-lucide="user"></i> User Profile
            </h4>
            
            <div style="display: flex; gap: 2rem; align-items: flex-start;">
                <div style="width: 100px; height: 100px; background: rgba(255,255,255,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; color: var(--primary);">
                    AD
                </div>
                <div style="flex-grow: 1;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div>
                            <label style="display: block; font-size: 0.875rem; margin-bottom: 0.5rem; color: var(--text-muted);">Name</label>
                            <input type="text" value="Administrator" style="width: 100%; padding: 0.75rem; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 8px;">
                        </div>
                        <div>
                            <label style="display: block; font-size: 0.875rem; margin-bottom: 0.5rem; color: var(--text-muted);">Email</label>
                            <input type="email" value="admin@amanischool.ac.tz" style="width: 100%; padding: 0.75rem; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 8px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="glass-panel animate-fade-in" style="padding: 2rem; animation-delay: 0.1s;">
            <h4 style="color: var(--secondary); margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem;">
                <i data-lucide="monitor"></i> Appearance
            </h4>
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                <div>
                    <div style="font-weight: 500;">Dark Theme</div>
                    <div class="text-muted" style="font-size: 0.875rem;">Use dark colors for the interface</div>
                </div>
                <div style="width: 50px; height: 28px; background: var(--primary); border-radius: 14px; position: relative;">
                    <div style="width: 24px; height: 24px; background: white; border-radius: 50%; position: absolute; right: 2px; top: 2px;"></div>
                </div>
            </div>

             <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-weight: 500;">Currency</div>
                    <div class="text-muted" style="font-size: 0.875rem;">Default currency for finance module</div>
                </div>
                <select style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); color: white; padding: 0.5rem; border-radius: 8px;">
                    <option value="TZS">Tanzanian Shilling (Tsh)</option>
                    <option value="USD">US Dollar ($)</option>
                </select>
            </div>
        </div>

    </div>

@endsection
