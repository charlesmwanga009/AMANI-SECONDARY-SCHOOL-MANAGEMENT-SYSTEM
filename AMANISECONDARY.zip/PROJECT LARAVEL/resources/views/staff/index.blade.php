@extends('layout')

@section('title', 'Staff Management - Amani School System')

@section('content')

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 class="animate-fade-in">Staff Management</h2>
        <button class="btn btn-primary"><i data-lucide="user-plus"></i> Add New Staff</button>
    </div>

    <div class="stats-grid animate-fade-in">
        <div class="glass-panel stat-card">
            <span class="stat-label">Total Staff</span>
            <div class="stat-value">{{ $staff_stats['total'] }}</div>
        </div>
        <div class="glass-panel stat-card">
            <span class="stat-label">Present Today</span>
            <div class="stat-value text-success">{{ $staff_stats['present_today'] }}</div>
        </div>
        <div class="glass-panel stat-card">
            <span class="stat-label">On Leave</span>
            <div class="stat-value text-danger">{{ $staff_stats['on_leave'] }}</div>
        </div>
    </div>

    <div class="glass-panel animate-fade-in" style="margin-top: 2rem; padding: 2rem;">
        <h3>Departmental Breakdown</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1.5rem;">
            @foreach($departments as $dept => $count)
            <div style="background: rgba(255,255,255,0.05); padding: 1rem; border-radius: 12px; display: flex; align-items: center; justify-content: space-between;">
                <span style="font-weight: 500;">{{ $dept }}</span>
                <span style="background: var(--primary); padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.8rem;">{{ $count }}</span>
            </div>
            @endforeach
        </div>
    </div>

@endsection
