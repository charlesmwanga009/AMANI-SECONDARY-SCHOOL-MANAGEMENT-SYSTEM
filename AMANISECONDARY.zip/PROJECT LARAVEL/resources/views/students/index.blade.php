@extends('layout')

@section('title', 'Student Management - Amani School System')

@section('content')

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 class="animate-fade-in">Student Body</h2>
        <a href="{{ route('students.create') }}" class="btn btn-primary"><i data-lucide="user-plus"></i> Enroll Student</a>
    </div>

    <div class="glass-panel animate-fade-in" style="padding: 1.5rem;">
        
        <!-- Filter Toolbar -->
        <div style="display: flex; gap: 1rem; margin-bottom: 2rem;">
            <div class="search-bar" style="flex-grow: 1;">
                <input type="text" placeholder="Search by name, ID, or class..." style="width: 100%;">
            </div>
            <select style="background: rgba(6, 78, 59, 0.5); border: 1px solid rgba(255,255,255,0.1); color: white; padding: 0.75rem; border-radius: 12px; outline: none;">
                <option value="">All Classes</option>
                <option value="1">Form 1</option>
                <option value="2">Form 2</option>
            </select>
            <select style="background: rgba(6, 78, 59, 0.5); border: 1px solid rgba(255,255,255,0.1); color: white; padding: 0.75rem; border-radius: 12px; outline: none;">
                <option value="">All Statuses</option>
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
            </select>
        </div>

        <!-- Students Table -->
        <table style="width: 100%; text-align: left; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.1); color: var(--text-muted);">
                    <th style="padding: 1rem;">Admission No</th>
                    <th style="padding: 1rem;">Full Name</th>
                    <th style="padding: 1rem;">Class</th>
                    <th style="padding: 1rem;">Parent Contact</th>
                    <th style="padding: 1rem;">Status</th>
                    <th style="padding: 1rem;">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($students as $student)
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <td style="padding: 1rem; font-family: monospace;">{{ $student->admission_number }}</td>
                    <td style="padding: 1rem; font-weight: 500;">
                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                            <div class="avatar" style="width: 32px; height: 32px; font-size: 0.75rem;">
                                {{ substr($student->first_name, 0, 1) }}{{ substr($student->last_name, 0, 1) }}
                            </div>
                            {{ $student->first_name }} {{ $student->last_name }}
                        </div>
                    </td>
                    <td style="padding: 1rem;">{{ $student->schoolClass ? $student->schoolClass->name . ' ' . $student->schoolClass->section : 'N/A' }}</td>
                    <td style="padding: 1rem;">{{ $student->parent_contact }}</td>
                    <td style="padding: 1rem;">
                        <span style="
                            padding: 0.25rem 0.75rem; 
                            border-radius: 50px; 
                            font-size: 0.75rem; 
                            background: {{ $student->status == 'active' ? 'rgba(22, 163, 74, 0.2)' : 'rgba(239, 68, 68, 0.2)' }}; 
                            color: {{ $student->status == 'active' ? '#4ade80' : '#ef4444' }};
                        ">
                            {{ ucfirst($student->status) }}
                        </span>
                    </td>
                    <td style="padding: 1rem;">
                        <button class="btn btn-glass" style="padding: 0.4rem;"><i data-lucide="edit-2" size="16"></i></button>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

@endsection
