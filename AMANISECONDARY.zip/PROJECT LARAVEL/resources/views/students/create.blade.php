@extends('layout')

@section('title', 'Enroll Student - Amani School System')

@section('content')
    
    <div style="max-width: 800px; margin: 0 auto;">
        <div style="margin-bottom: 2rem;">
            <a href="{{ route('students.index') }}" style="color: var(--text-muted); display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                <i data-lucide="arrow-left" size="16"></i> Back to Students
            </a>
            <h2 class="animate-fade-in">New Student Enrollment</h2>
            <p class="text-muted">Enter the student's details to register them into the system.</p>
        </div>

        <div class="glass-panel animate-fade-in" style="padding: 2.5rem;">
            <form action="{{ route('students.store') }}" method="POST">
                @csrf
                
                <!-- Personal Info -->
                <h4 style="color: var(--secondary); margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem;">Personal Information</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                    
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">First Name</label>
                        <input type="text" name="first_name" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Last Name</label>
                        <input type="text" name="last_name" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Date of Birth</label>
                        <input type="date" name="date_of_birth" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Gender</label>
                        <select name="gender" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>

                </div>

                <!-- Academic Info -->
                <h4 style="color: var(--secondary); margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem;">Academic Details</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                    
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Admission Number</label>
                        <input type="text" name="admission_number" placeholder="ADM-YEAR-XXX" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Class Assignment</label>
                        <select name="class_id" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                            @foreach($classes as $class)
                                <option value="{{ $class->id }}">{{ $class->name }} {{ $class->section }}</option>
                            @endforeach
                        </select>
                    </div>

                </div>

                <!-- Guardian Info -->
                <h4 style="color: var(--secondary); margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem;">Guardian Information</h4>
                <div style="display: grid; grid-template-columns: 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Parent/Guardian Contact</label>
                        <input type="text" name="parent_contact" placeholder="+255..." style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;">
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 500;">Home Address</label>
                        <textarea name="address" rows="3" style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 0.75rem; border-radius: 8px; color: white; outline: none;"></textarea>
                    </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 1rem;">
                    <button type="button" class="btn btn-glass">Cancel</button>
                    <button type="submit" class="btn btn-primary">Complete Enrollment</button>
                </div>

            </form>
        </div>
    </div>

@endsection
